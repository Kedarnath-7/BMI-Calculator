package com.example.bmicalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
